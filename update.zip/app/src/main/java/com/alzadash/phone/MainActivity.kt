package com.alzadash.phone

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.alzadash.car.CarSurface
import com.alzadash.core.Background
import com.alzadash.core.Chime
import com.alzadash.core.Launch
import com.alzadash.core.NowPlaying
import com.alzadash.core.Pkg
import com.alzadash.core.Prefs
import com.alzadash.core.Shell

/** The phone companion: quick launch buttons, tools and setup. */
class MainActivity : AppCompatActivity() {
    private lateinit var prefs: Prefs
    private lateinit var shizukuStatus: android.widget.TextView
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    private val askPermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val missing = it.filterValues { granted -> !granted }.keys
        toast(if (missing.isEmpty()) "All set" else "Some permissions were not allowed")
    }

    private val pickApk = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) ApkInstaller.install(this, uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        val accent = getColor(com.alzadash.R.color.accent)

        col.addView(heading("QUICK LAUNCH"))
        col.addView(buttonRow(
            bigButton("Play Store") { Launch.app(this, Pkg.PLAY_STORE) },
            bigButton("Netflix") { Launch.app(this, Pkg.NETFLIX) },
        ))
        col.addView(buttonRow(
            bigButton("YouTube") { Launch.app(this, Pkg.YOUTUBE) },
            bigButton("Disney+ Hotstar") { Launch.app(this, "in.startv.hotstar.dplus") },
        ))
        col.addView(buttonRow(
            bigButton("Gemini", accent) { Launch.gemini(this) },
        ))
        col.addView(buttonRow(
            bigButton("Google Maps") { Launch.app(this, Pkg.MAPS) },
            bigButton("Waze") { Launch.app(this, Pkg.WAZE) },
        ))

        col.addView(heading("TOOLS"))
        col.addView(buttonRow(
            bigButton("All apps") { startActivity(Intent(this, AppsActivity::class.java)) },
            bigButton("Install APK") { installApk() },
        ))
        col.addView(buttonRow(
            bigButton("Radio stations") { startActivity(Intent(this, StationsActivity::class.java)) },
            bigButton("Test welcome sound") { Chime.play() },
        ))

        col.addView(heading("CAR SCREEN"))
        col.addView(buttonRow(
            bigButton("Car shortcuts") { startActivity(Intent(this, DockPickerActivity::class.java)) },
            bigButton("Background") { chooseBackground() },
        ))
        // Typing into an app open on the car screen. Tapping a text box there also brings up this phone's keyboard.
        val typeBox = EditText(this).apply {
            hint = "Type here to send to the car screen"
            isSingleLine = true
        }
        col.addView(typeBox)
        col.addView(buttonRow(
            bigButton("Send text", accent) {
                val surface = CarSurface.active?.get()
                if (surface == null || surface.displayId < 0) {
                    toast("Connect to the car first")
                } else if (!Shell.available()) {
                    toast("Shizuku is needed for this")
                } else {
                    surface.typeText(typeBox.text.toString())
                    typeBox.setText("")
                }
            },
            bigButton("Enter") { CarSurface.active?.get()?.let { Shell.key(it.displayId, 66) } },
        ))

        col.addView(heading("SETUP"))
        shizukuStatus = note("")
        col.addView(shizukuStatus)
        col.addView(buttonRow(
            bigButton("Allow Shizuku", accent) {
                if (!Shell.running()) toast("Open Shizuku and tap Start first") else Shell.requestPermission()
                handler.postDelayed({ updateShizuku() }, 1500)
            },
        ))
        col.addView(buttonRow(
            bigButton("Allow permissions", accent) { requestPermissions() },
            bigButton("Show song on dash") { openNowPlayingAccess() },
        ))
        col.addView(toggle("Welcome sound", prefs.welcomeSound) { prefs.welcomeSound = it })
        col.addView(toggle("Auto start on car Bluetooth", prefs.autoStartOnBluetooth) { prefs.autoStartOnBluetooth = it })
        col.addView(toggle("Resume radio on connect", prefs.resumeRadioOnConnect) { prefs.resumeRadioOnConnect = it })
        col.addView(textField("Car Bluetooth name (blank = any)", prefs.carBluetoothName) { prefs.carBluetoothName = it })
        col.addView(textField("Home address", prefs.homeAddress) { prefs.homeAddress = it })

        col.addView(heading("ON THE CAR SCREEN"))
        col.addView(note(
            "In Android Auto settings, tap Version 10 times to unlock developer settings, " +
                "then turn on Unknown sources. AlzaDash then appears in the car's app list.\n\n" +
                "Video on the car screen plays only while the car is stopped. While moving, the picture is hidden and only sound continues.\n\n" +
                "To open YouTube, Netflix and Hotstar as real apps on the car screen, Shizuku must be running and allowed above."
        ))

        setContentView(ScrollView(this).apply { addView(col) })

        // Ask for everything the car screen needs the first time the app is opened.
        if (!prefs.askedPermissions) {
            prefs.askedPermissions = true
            requestPermissions()
        }
    }

    override fun onResume() {
        super.onResume()
        updateShizuku()
    }

    private fun updateShizuku() {
        shizukuStatus.text = when {
            Shell.available() -> "Shizuku: connected. YouTube, Netflix and Hotstar open as real apps on the car screen."
            Shell.running() -> "Shizuku: running, but AlzaDash isn't allowed yet. Tap Allow Shizuku."
            else -> "Shizuku: not running. Without it the car screen uses websites instead of the real video apps."
        }
    }

    private fun toggle(label: String, value: Boolean, onChange: (Boolean) -> Unit) = SwitchCompat(this).apply {
        text = label
        textSize = 17f
        isChecked = value
        minHeight = dp(56)
        setOnCheckedChangeListener { _, checked -> onChange(checked) }
    }

    private fun textField(hint: String, value: String, onChange: (String) -> Unit) = EditText(this).apply {
        this.hint = hint
        setText(value)
        isSingleLine = true
        setOnFocusChangeListener { _, focused -> if (!focused) onChange(text.toString()) }
        addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) = onChange(s.toString())
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private val pickBackground = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) toast(if (Background.fromUri(this, uri)) "Background set" else "Couldn't use that picture")
    }

    /** Uses the phone's wallpaper if Android allows it, otherwise lets you pick a picture. */
    private fun chooseBackground() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Dashboard background")
            .setItems(arrayOf("Use my phone wallpaper", "Pick a picture", "Plain dark")) { _, which ->
                when (which) {
                    0 -> if (Background.fromWallpaper(this)) {
                        toast("Background set")
                    } else {
                        toast("Android doesn't let apps read the wallpaper. Pick the same picture from your gallery instead.")
                        pickBackground.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                    1 -> pickBackground.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    else -> { Background.clear(this); toast("Background removed") }
                }
            }
            .show()
    }

    private fun requestPermissions() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.RECORD_AUDIO,
        )
        if (Build.VERSION.SDK_INT >= 31) perms += Manifest.permission.BLUETOOTH_CONNECT
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        askPermissions.launch(perms.toTypedArray())
    }

    private fun openNowPlayingAccess() {
        if (NowPlaying.hasAccess(this)) {
            toast("Already allowed")
            return
        }
        toast("Turn on AlzaDash in the list")
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }

    private fun installApk() {
        if (!packageManager.canRequestPackageInstalls()) {
            toast("Allow AlzaDash to install apps, then tap Install APK again")
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        pickApk.launch(arrayOf("application/vnd.android.package-archive"))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
